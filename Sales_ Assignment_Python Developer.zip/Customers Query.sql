
/*
====================================================
PROJECT: SALES PERFORMANCE DASHBOARD
DATABASE: SalesDB
TOOLS: SQL SERVER + SSMS + POWER BI
====================================================
*/


/* ================================================
   1. CREATE DATABASE
================================================ */

IF DB_ID('SalesDB') IS NULL
BEGIN
    CREATE DATABASE SalesDB;
END;
GO

USE SalesDB;
GO


/* ================================================
   2. CREATE CUSTOMERS TABLE
================================================ */

IF OBJECT_ID('dbo.Customers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Customers
    (
        Customer_ID VARCHAR(20) PRIMARY KEY,
        Customer_Name VARCHAR(100),
        Email VARCHAR(150),
        City VARCHAR(100),
        State VARCHAR(100),
        Customer_Segment VARCHAR(50),
        Join_Date DATE,
        Acquisition_Channel VARCHAR(50)
    );
END;
GO


/* ================================================
   3. CREATE ORDERS TABLE
================================================ */

IF OBJECT_ID('dbo.Orders', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Orders
    (
        Order_ID VARCHAR(20) PRIMARY KEY,
        Customer_ID VARCHAR(20) NOT NULL,
        Order_Date DATE,
        Product_ID VARCHAR(20),
        Product_Name VARCHAR(150),
        Category VARCHAR(100),
        Quantity INT,
        Unit_Price_INR DECIMAL(12,2),
        Discount_Rate DECIMAL(5,4),
        Net_Amount_INR DECIMAL(12,2),
        Payment_Method VARCHAR(50),
        Order_Status VARCHAR(50),

        CONSTRAINT FK_Orders_Customers
        FOREIGN KEY (Customer_ID)
        REFERENCES dbo.Customers(Customer_ID)
    );
END;
GO


/* ================================================
   4. VERIFY DATABASE TABLES
================================================ */

SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE';
GO


/* ================================================
   5. VERIFY CUSTOMER STAGING DATA
   Imported using Import Flat File wizard
================================================ */

SELECT COUNT(*) AS StagingCustomers
FROM dbo.customers_stage;
GO

SELECT TOP 10 *
FROM dbo.customers_stage;
GO


/* ================================================
   6. INSERT STAGING DATA INTO CUSTOMERS
   Only inserts if Customers is empty
================================================ */

IF NOT EXISTS (SELECT 1 FROM dbo.Customers)
BEGIN
    INSERT INTO dbo.Customers
    (
        Customer_ID,
        Customer_Name,
        Email,
        City,
        State,
        Customer_Segment,
        Join_Date,
        Acquisition_Channel
    )
    SELECT
        Customer_ID,
        Customer_Name,
        Email,
        City,
        State,
        Customer_Segment,
        Join_Date,
        Acquisition_Channel
    FROM dbo.customers_stage;
END;
GO


/* ================================================
   7. VERIFY FINAL CUSTOMERS TABLE
================================================ */

SELECT TOP 10 *
FROM dbo.Customers;
GO

SELECT
    COUNT(*) AS TotalCustomers,
    COUNT(DISTINCT Customer_ID) AS UniqueCustomers
FROM dbo.Customers;
GO


/* ================================================
   8. VERIFY DUPLICATE CUSTOMER IDS
================================================ */

SELECT
    Customer_ID,
    COUNT(*) AS DuplicateCount
FROM dbo.Customers
GROUP BY Customer_ID
HAVING COUNT(*) > 1;
GO


/* ================================================
   9. VERIFY CUSTOMER NULL VALUES
================================================ */

SELECT *
FROM dbo.Customers
WHERE
    Customer_ID IS NULL
    OR Customer_Name IS NULL
    OR Email IS NULL
    OR City IS NULL
    OR State IS NULL
    OR Customer_Segment IS NULL;
GO


/* ================================================
   10. FINAL CUSTOMER COUNT
================================================ */

SELECT
    'Customers' AS TableName,
    COUNT(*) AS TotalRecords
FROM dbo.Customers;
GO


