
/* ======================================================
   1. CREATE DATABASE
====================================================== */

IF DB_ID('SalesDB') IS NULL
BEGIN
    CREATE DATABASE SalesDB;
END;
GO

USE SalesDB;
GO


/* ======================================================
   2. CREATE CUSTOMERS TABLE
====================================================== */

IF OBJECT_ID('dbo.Customers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Customers
    (
        Customer_ID VARCHAR(20) PRIMARY KEY,
        Customer_Name VARCHAR(100),
        Email VARCHAR(150),
        City VARCHAR(100),
        State VARCHAR(100),
        Customer_Segment VARCHAR(50),
        Join_Date DATE,
        Acquisition_Channel VARCHAR(50)
    );
END;
GO


/* ======================================================
   3. CREATE ORDERS TABLE
====================================================== */

IF OBJECT_ID('dbo.Orders', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Orders
    (
        Order_ID VARCHAR(20) PRIMARY KEY,
        Customer_ID VARCHAR(20) NOT NULL,
        Order_Date DATE,
        Product_ID VARCHAR(20),
        Product_Name VARCHAR(150),
        Category VARCHAR(100),
        Quantity INT,
        Unit_Price_INR DECIMAL(12,2),
        Discount_Rate DECIMAL(5,4),
        Net_Amount_INR DECIMAL(12,2),
        Payment_Method VARCHAR(50),
        Order_Status VARCHAR(50),

        FOREIGN KEY (Customer_ID)
        REFERENCES dbo.Customers(Customer_ID)
    );
END;
GO


/* ======================================================
   4. IMPORT CUSTOMER DATA INTO FINAL TABLE
====================================================== */

IF NOT EXISTS (SELECT 1 FROM dbo.Customers)
BEGIN
    INSERT INTO dbo.Customers
    (
        Customer_ID,
        Customer_Name,
        Email,
        City,
        State,
        Customer_Segment,
        Join_Date,
        Acquisition_Channel
    )
    SELECT
        Customer_ID,
        Customer_Name,
        Email,
        City,
        State,
        Customer_Segment,
        Join_Date,
        Acquisition_Channel
    FROM dbo.customers_stage;
END;
GO


/* ======================================================
   5. IMPORT ORDERS DATA INTO FINAL TABLE
====================================================== */

IF NOT EXISTS (SELECT 1 FROM dbo.Orders)
BEGIN
    INSERT INTO dbo.Orders
    (
        Order_ID,
        Customer_ID,
        Order_Date,
        Product_ID,
        Product_Name,
        Category,
        Quantity,
        Unit_Price_INR,
        Discount_Rate,
        Net_Amount_INR,
        Payment_Method,
        Order_Status
    )
    SELECT
        Order_ID,
        Customer_ID,
        Order_Date,
        CONVERT(VARCHAR(20), CONVERT(INT, Product_ID)),
        Product_Name,
        Category,
        CONVERT(INT, Quantity),
        CONVERT(DECIMAL(12,2), Unit_Price_INR),

        CONVERT(
            DECIMAL(5,4),
            CONVERT(
                DECIMAL(5,2),
                REPLACE(Discount_Rate, '%', '')
            ) / 100.0
        ),

        CONVERT(DECIMAL(12,2), Net_Amount_INR),
        Payment_Method,
        Order_Status

    FROM dbo.orders_stages;
END;
GO


/* ======================================================
   6. VERIFY CUSTOMER DATA
====================================================== */

SELECT *
FROM dbo.Customers;
GO

SELECT COUNT(*) AS Total_Customers
FROM dbo.Customers;
GO


/* ======================================================
   7. VERIFY ORDERS DATA
====================================================== */

SELECT *
FROM dbo.Orders;
GO

SELECT COUNT(*) AS Total_Orders
FROM dbo.Orders;
GO


/* ======================================================
   8. CHECK DUPLICATE CUSTOMER RECORDS
====================================================== */

SELECT
    Customer_ID,
    COUNT(*) AS Total_Records
FROM dbo.Customers
GROUP BY Customer_ID
HAVING COUNT(*) > 1;
GO


/* ======================================================
   9. CHECK DUPLICATE ORDER RECORDS
====================================================== */

SELECT
    Order_ID,
    COUNT(*) AS Total_Records
FROM dbo.Orders
GROUP BY Order_ID
HAVING COUNT(*) > 1;
GO


/* ======================================================
   10. OVERALL SALES PERFORMANCE
====================================================== */

SELECT
    COUNT(DISTINCT Order_ID) AS Total_Orders,
    SUM(Net_Amount_INR) AS Total_Revenue,
    COUNT(DISTINCT Customer_ID) AS Total_Customers,
    AVG(Net_Amount_INR) AS Average_Order_Value
FROM dbo.Orders;
GO


/* ======================================================
   11. MONTHLY SALES ANALYSIS
====================================================== */

SELECT
    YEAR(Order_Date) AS Sales_Year,
    MONTH(Order_Date) AS Sales_Month,
    SUM(Net_Amount_INR) AS Monthly_Revenue,
    COUNT(Order_ID) AS Total_Orders
FROM dbo.Orders
GROUP BY
    YEAR(Order_Date),
    MONTH(Order_Date)
ORDER BY
    Sales_Year,
    Sales_Month;
GO


/* ======================================================
   12. CATEGORY-WISE SALES ANALYSIS
====================================================== */

SELECT
    Category,
    SUM(Quantity) AS Total_Quantity,
    COUNT(Order_ID) AS Total_Orders,
    SUM(Net_Amount_INR) AS Total_Revenue
FROM dbo.Orders
GROUP BY Category
ORDER BY Total_Revenue DESC;
GO


/* ======================================================
   13. CUSTOMER SEGMENT ANALYSIS
====================================================== */

SELECT
    c.Customer_Segment,
    COUNT(DISTINCT c.Customer_ID) AS Total_Customers,
    COUNT(o.Order_ID) AS Total_Orders,
    SUM(o.Net_Amount_INR) AS Total_Revenue
FROM dbo.Customers c
INNER JOIN dbo.Orders o
    ON c.Customer_ID = o.Customer_ID
GROUP BY c.Customer_Segment
ORDER BY Total_Revenue DESC;
GO


/* ======================================================
   14. CITY-WISE SALES ANALYSIS
====================================================== */

SELECT
    c.City,
    c.State,
    COUNT(o.Order_ID) AS Total_Orders,
    SUM(o.Net_Amount_INR) AS Total_Revenue
FROM dbo.Customers c
INNER JOIN dbo.Orders o
    ON c.Customer_ID = o.Customer_ID
GROUP BY
    c.City,
    c.State
ORDER BY Total_Revenue DESC;
GO


/* ======================================================
   15. TOP 5 PRODUCTS BY REVENUE
====================================================== */

SELECT TOP 5
    Product_Name,
    Category,
    SUM(Quantity) AS Total_Quantity,
    SUM(Net_Amount_INR) AS Total_Revenue
FROM dbo.Orders
GROUP BY
    Product_Name,
    Category
ORDER BY Total_Revenue DESC;
GO


/* ======================================================
   16. PAYMENT METHOD ANALYSIS
====================================================== */

SELECT
    Payment_Method,
    COUNT(Order_ID) AS Total_Orders,
    SUM(Net_Amount_INR) AS Total_Revenue
FROM dbo.Orders
GROUP BY Payment_Method
ORDER BY Total_Revenue DESC;
GO


/* ======================================================
   17. ORDER STATUS ANALYSIS
====================================================== */

SELECT
    Order_Status,
    COUNT(Order_ID) AS Total_Orders,
    SUM(Net_Amount_INR) AS Total_Revenue
FROM dbo.Orders
GROUP BY Order_Status
ORDER BY Total_Orders DESC;
GO


/* ======================================================
   18. CUSTOMER AND ORDER DETAILS
====================================================== */

SELECT
    c.Customer_ID,
    c.Customer_Name,
    c.City,
    c.Customer_Segment,
    o.Order_ID,
    o.Order_Date,
    o.Product_Name,
    o.Category,
    o.Net_Amount_INR,
    o.Order_Status
FROM dbo.Customers c
INNER JOIN dbo.Orders o
    ON c.Customer_ID = o.Customer_ID
ORDER BY o.Order_Date;
GO


/* ======================================================
   19. CUSTOMERS WITHOUT ORDERS
====================================================== */

SELECT
    c.Customer_ID,
    c.Customer_Name,
    c.City,
    c.Customer_Segment
FROM dbo.Customers c
LEFT JOIN dbo.Orders o
    ON c.Customer_ID = o.Customer_ID
WHERE o.Order_ID IS NULL;
GO


/* ======================================================
   20. FINAL PROJECT SUMMARY
====================================================== */

SELECT
    (SELECT COUNT(*) FROM dbo.Customers)
        AS Total_Customers,

    (SELECT COUNT(*) FROM dbo.Orders)
        AS Total_Orders,

    (SELECT SUM(Net_Amount_INR) FROM dbo.Orders)
        AS Total_Revenue,

    (SELECT COUNT(DISTINCT Customer_ID)
     FROM dbo.Orders)
        AS Ordering_Customers;
GO


