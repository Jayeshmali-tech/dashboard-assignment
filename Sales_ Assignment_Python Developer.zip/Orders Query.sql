
/*
====================================================
PROJECT: SALES PERFORMANCE DASHBOARD
SECTION: ORDERS DATA IMPORT
DATABASE: SalesDB
====================================================
*/

USE SalesDB;
GO


/* ================================================
   1. VERIFY STAGING DATA
================================================ */

SELECT COUNT(*) AS TotalStagingOrders
FROM dbo.orders_stages;
GO


/* ================================================
   2. CHECK DUPLICATE ORDER IDS
================================================ */

SELECT
    Order_ID,
    COUNT(*) AS DuplicateCount
FROM dbo.orders_stages
GROUP BY Order_ID
HAVING COUNT(*) > 1;
GO


/* ================================================
   3. CHECK INVALID CUSTOMER REFERENCES
================================================ */

SELECT
    o.Order_ID,
    o.Customer_ID
FROM dbo.orders_stages o
LEFT JOIN dbo.Customers c
    ON o.Customer_ID = c.Customer_ID
WHERE c.Customer_ID IS NULL;
GO


/* ================================================
   4. CHECK INVALID DISCOUNT VALUES
================================================ */

SELECT DISTINCT Discount_Rate
FROM dbo.orders_stages;
GO


/* ================================================
   5. INSERT DATA INTO FINAL ORDERS TABLE
================================================ */

IF EXISTS (SELECT 1 FROM dbo.Orders)
BEGIN
    THROW 50001,
    'Orders table is not empty. Insertion stopped.',
    1;
END;
GO

IF (SELECT COUNT(*) FROM dbo.orders_stages) <> 240
BEGIN
    THROW 50002,
    'Expected 240 staging orders. Insertion stopped.',
    1;
END;
GO

IF EXISTS
(
    SELECT 1
    FROM dbo.orders_stages
    WHERE TRY_CONVERT(
        DECIMAL(5,2),
        REPLACE(LTRIM(RTRIM(Discount_Rate)), '%', '')
    ) IS NULL
    OR TRY_CONVERT(
        DECIMAL(5,2),
        REPLACE(LTRIM(RTRIM(Discount_Rate)), '%', '')
    ) NOT BETWEEN 0 AND 100
)
BEGIN
    THROW 50003,
    'Invalid discount values detected.',
    1;
END;
GO

IF EXISTS
(
    SELECT 1
    FROM dbo.orders_stages
    WHERE Product_ID IS NULL
       OR Product_ID <> FLOOR(Product_ID)
)
BEGIN
    THROW 50004,
    'Invalid Product_ID values detected.',
    1;
END;
GO

BEGIN TRY

    BEGIN TRANSACTION;

    INSERT INTO dbo.Orders
    (
        Order_ID,
        Customer_ID,
        Order_Date,
        Product_ID,
        Product_Name,
        Category,
        Quantity,
        Unit_Price_INR,
        Discount_Rate,
        Net_Amount_INR,
        Payment_Method,
        Order_Status
    )

    SELECT
        Order_ID,
        Customer_ID,
        Order_Date,

        CONVERT(VARCHAR(20), CONVERT(INT, Product_ID)),

        Product_Name,
        Category,
        CONVERT(INT, Quantity),

        CONVERT(DECIMAL(12,2), Unit_Price_INR),

        CONVERT(
            DECIMAL(5,4),
            TRY_CONVERT(
                DECIMAL(5,2),
                REPLACE(LTRIM(RTRIM(Discount_Rate)), '%', '')
            ) / 100.0
        ),

        CONVERT(DECIMAL(12,2), Net_Amount_INR),

        Payment_Method,
        Order_Status

    FROM dbo.orders_stages;

    COMMIT TRANSACTION;

    PRINT '240 Orders inserted successfully.';

END TRY

BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;

END CATCH;
GO


/* ================================================
   6. VERIFY FINAL ORDERS DATA
================================================ */

SELECT COUNT(*) AS TotalOrders
FROM dbo.Orders;
GO

SELECT TOP 10 *
FROM dbo.Orders;
GO


/* ================================================
   7. VERIFY DISCOUNT CONVERSION
================================================ */

SELECT DISTINCT
    Discount_Rate
FROM dbo.Orders
ORDER BY Discount_Rate;
GO


/* ================================================
   8. ORDER STATUS ANALYSIS
================================================ */

SELECT
    Order_Status,
    COUNT(*) AS TotalOrders,
    SUM(Net_Amount_INR) AS TotalRevenue
FROM dbo.Orders
GROUP BY Order_Status;
GO


/* ================================================
   9. TOTAL SALES ANALYSIS
================================================ */

SELECT
    SUM(Net_Amount_INR) AS TotalRevenue,
    COUNT(*) AS TotalOrders,
    COUNT(DISTINCT Customer_ID) AS UniqueCustomers
FROM dbo.Orders;
GO


/* ================================================
   10. JOIN CUSTOMERS AND ORDERS
================================================ */

SELECT
    o.Order_ID,
    c.Customer_Name,
    c.City,
    c.Customer_Segment,
    o.Product_Name,
    o.Category,
    o.Quantity,
    o.Unit_Price_INR,
    o.Discount_Rate,
    o.Net_Amount_INR,
    o.Order_Status

FROM dbo.Orders o

INNER JOIN dbo.Customers c
    ON o.Customer_ID = c.Customer_ID;
GO


/* ================================================
   11. FINAL DATABASE SUMMARY
================================================ */

SELECT
    (SELECT COUNT(*) FROM dbo.Customers)
        AS TotalCustomers,

    (SELECT COUNT(*) FROM dbo.Orders)
        AS TotalOrders,

    (SELECT COUNT(DISTINCT Order_ID) FROM dbo.Orders)
        AS UniqueOrders,

    (SELECT SUM(Net_Amount_INR) FROM dbo.Orders)
        AS TotalRevenue;
GO
