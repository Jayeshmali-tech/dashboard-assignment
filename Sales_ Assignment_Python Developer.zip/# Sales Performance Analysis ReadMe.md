# Sales Performance Analysis

## Project Overview

This project analyzes sales performance using SQL Server and Power BI.

It includes:
- SQL Server database for storing customer and order information.
- Data staging and transformation using SQL.
- DAX measures for sales KPIs and performance analysis.
- Power BI dashboard with interactive filters.
- Docker Compose configuration for running SQL Server in a container.

## Technology Stack

| Technology | Purpose |
|---|---|
| SQL Server Express 2022 | Database |
| SQL Server Management Studio | Database management |
| Docker Desktop | Database containerization |
| Docker Compose | Container configuration |
| Power BI Desktop | Dashboard and visualization |
| DAX | KPI calculations |

## Project Structure

```text
Sales-Performance-Analysis/
│
├── docker-compose.yml
├── .env
├── .gitignore
├── README.md
│
├── sql/
│   └── Sales_Performance_Analysis.sql
│
├── data/
│   ├── customers.csv
│   └── orders.csv
│
└── powerbi/
    └── Sales_Performance_Dashboard.pbix
```

## Database Details

Database name: `SalesDB`

Main tables:

**Customers**
- Customer_ID
- Customer_Name
- Email
- City
- State
- Customer_Segment
- Join_Date
- Acquisition_Channel

**Orders**
- Order_ID
- Customer_ID
- Order_Date
- Product_ID
- Product_Name
- Category
- Quantity
- Unit_Price_INR
- Discount_Rate
- Net_Amount_INR
- Payment_Method
- Order_Status

## Docker Setup

### Prerequisites

- Docker Desktop
- SQL Server Management Studio
- Power BI Desktop

### 1. Configure environment variables

Create a `.env` file in the project root:

```env
MSSQL_SA_PASSWORD=YourStrongPassword@123
```

Use your own strong password. Do not commit `.env` to version control.

### 2. Start the SQL Server container

Run:

```bash
docker compose up -d
```

### 3. Verify the container

```bash
docker ps
```

View logs:

```bash
docker logs sales-sqlserver
```

### 4. Connect to SQL Server

Use these connection details in SSMS:

- Server: `localhost,14330`
- Authentication: SQL Server Authentication
- Username: `sa`
- Password: Value configured in `.env`

### 5. Load the database

Import the CSV files into the staging tables:

- `dbo.customers_stage`
- `dbo.orders_stages`

Then execute:

`sql/Sales_Performance_Analysis.sql`

Verify that the final Customers and Orders tables have loaded correctly.

## Power BI Dashboard Setup

Open Power BI Desktop.

1. Select Get Data.
2. Select SQL Server.
3. Enter `localhost,14330`.
4. Select database `SalesDB`.
5. Import Customers and Orders.
6. Verify the relationship between the two tables.

Relationship:

`Customers[Customer_ID]` → `Orders[Customer_ID]`

The report contains sales KPIs, revenue analysis, product performance, customer analysis and order status analysis.

### Interactive Filters

The dashboard includes:

1. Order Date Range
2. Product Category

These slicers allow users to filter dashboard visuals interactively.

## Running the Project

Start the database:

```bash
docker compose up -d
```

Stop the database container:

```bash
docker compose stop
```

Restart the database:

```bash
docker compose start
```

Remove the container while preserving database data:

```bash
docker compose down
```

The database files are stored in the persistent Docker volume `salesdb_data`.

**Important:** Do not use `docker compose down -v` unless you intend to delete the database volume.

## Data Validation

After loading the database, verify:

- Total customers: 60
- Total orders: 240
- Unique order IDs: 240

Compare total revenue against the original SQL database before considering the migration complete.

## Important Notes

- Docker runs the SQL Server database, not Power BI Desktop.
- Power BI Desktop runs on the Windows host and connects to the Docker database.
- The database volume preserves data across container restarts.
- CSV files and SQL scripts are used to recreate the database in a new environment.
- The `.env` file contains credentials and must not be uploaded to a public repository.

## Author

Sales Performance Analysis Project
